Installation and Configuration
How to Install the Driver
1) Plug the Cable into a USB port.
2) The ��Welcome to the Found New Hardware Wizard��  or "Add New Hardware Wizard" (Win98) should appear. If it doesn��t appear, go to step 9.
3) Ensure the product driver CD (included with package) has been inserted in your CD-ROM drive.
4) Select the option: ��Install the software automatically (Recommended).�� or "Search for the best driver for your device" (Win98)
5) Press ��Next��. Win 98 users should check CD-ROM drive.
6) Windows should find the ��Prolific USB-to-Serial Comm Port�� driver. Otherwise you should find the directory under your version of Windows under the "USB to RS232 1.1" directory on the CD-ROM. Windows 98 lists the device as "GM USB to Serial Bridge"
7) You will probably see a message indicating that the driver has not passed Windows Logo testing. Press ��Continue Anyway.�� This warning can be safely ignored.
8) Press ��Finish�� when prompted by Windows to complete the installation.

*** If the ��Found New Hardware Wizard�� did not appear in step 2 ***
9) Open Device Manager by doing the following:
   a) Click on ��Start�� and then ��Control Panel.��
   b) Switch to Classic View (if in Category View).
   c) Double click on ��System.��
   d) Select the Hardware tab.
   e) Press the ��Device Manager�� button.
10) Under ��Ports (COM & LPT),�� look for a USB Device entry with a yellow exclamation point '!' by it.
11) Right click on the USB Device and select ��Update Driver.��
12) This should bring up the ��Welcome to the Hardware Update Wizard.��
13) Ensure the product driver CD (included with package) is inserted in your CD-ROM drive.
14) Select the option: ��Install the software automatically (Recommended).��
15) Press ��Next.�� Continue from step 5 above.

Looking for Drivers?

How to Check the Driver Installation
1) Go to the Device Manager:

Windows XP:  Start -> Control Panel -> System -> Hardware -> Device Manager

Windows 2000/2003:  Start -> Settings -> Control Panel -> System -> Hardware -> Device Manager

Windows 98/ME: Start -> Settings -> Control Panel -> System -> Device Manager

2) Click on the plus sign (+) next to "Ports."

3) If the device is installed properly, you will see "Prolific USB-to-Serial Comm Port. (COMx)" or "USB to Serial Port (COMx)" (Win98). Note that x is the number of the COM port (typically 1-8)  assigned to the adapter.

The driver is installed properly, but the device is not working
First check to see that the Beagle Software application is set to the correct COM port number. To determine the COM port number assigned to the adapter, check the Device Manager (see above). 

It is also possible that the COM port number assigned is too high. Sometimes a device won't  work with the USB-to-Serial adapter even though everything appears to have installed correctly because some computers will only scan a limited number of COM ports.

For instance, it is possible that a computers has a limitation of scanning the first four COM ports. If the adapter is installed on COM5, a device with such a limitation will not work until the COM port is reassigned to COM1 - COM4.

Windows XP, 2000, ME, and 98  include a function that allows you to reassign the COM port.  Simply follow the instructions below:

Windows XP port reassignment

1) Follow steps 1 and 2 in "How to Check the Driver Installation."

2) Right click on the "Prolific USB to Serial Port" and click on Properties

3) Click on the "Port Settings" tab. Click the "Advanced" button.

4) Pull down the scrollbar on the bottom, left side and select COM 1, 2, 3 or 4 (NOTE: Choose one that does not say "in use" next to it). Click "OK."

5) Click "OK" again. Notice that the device will show up as being on the same COM port that it was before (i.e., COM5), but will show up on the new port if you close the Device Manager and open it again.

6) Close the device manager. You may have to run the software that came with your device to make it rescan the COM ports.

Windows 2000, ME, and 98SE port reassignment

1) Follow steps 1 and 2 in "How to Check the Driver Installation."

2) Right click on the "Prolific USB to Serial Port" and click on Properties

3) Click on the "Port Settings" tab. Click on the Resources tab.

4) Uncheck the box that says "Use automatic settings".

5) Select "Input/Output range".  Click on "Change Settings".

6) Type "02E8-02EF" in the Value box.  This value will change the port to COM 4.  If COM 4 is in use, you must choose another port.  The values for each port are:

COM 1:  03F8-03FF

COM 2:  02F8-02FF

COM 3:  03E8-03EF

COM 4:  02E8-02EF

7) After entering the value, click OK.  Click OK again and click Yes when the "Creating a Forced Configuration" window appears.  Click OK again.

8) Restart your computer.  If you go into the device manager, you will see that the COM port has changed to the one you have selected.

